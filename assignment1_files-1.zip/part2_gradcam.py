"""
part2_gradcam.py
Generate Grad-CAM visualizations (using pytorch-grad-cam)
Preconditions: trained model weights (best_resnet50.pth) from part1 available.
This script loads the model, runs inference on test images, and saves Grad-CAM overlays for N images.

Run in Colab:
pip install -q torch torchvision pytorch-grad-cam matplotlib opencv-python
python part2_gradcam.py --data_dir /content/CUB_200_2011/test --model_path /content/checkpoints/best_resnet50.pth --out_dir /content/gradcam_out --num_images 10
"""

import os
import argparse
from pathlib import Path
import torch
import numpy as np
from torchvision import models, transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
from PIL import Image
import matplotlib.pyplot as plt
import cv2

# Grad-CAM imports
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image

def load_model(model_path, num_classes, device):
    model = models.resnet50(pretrained=True)
    in_features = model.fc.in_features
    model.fc = torch.nn.Linear(in_features, num_classes)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.to(device).eval()
    return model

def get_dataset_loader(data_dir, img_size=224, batch_size=1):
    tfm = transforms.Compose([
        transforms.Resize((img_size,img_size)),
        transforms.ToTensor(),
    ])
    ds = ImageFolder(data_dir, transform=tfm)
    loader = DataLoader(ds, batch_size=batch_size, shuffle=False)
    return ds, loader

def denormalize(img_tensor):
    # img_tensor: C,H,W with ImageFolder transform (0-1)
    img = img_tensor.numpy().transpose(1,2,0)
    return img

def main(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ds, loader = get_dataset_loader(args.data_dir, args.img_size, args.batch_size)
    classes = ds.classes
    model = load_model(args.model_path, len(classes), device)
    target_layer = model.layer4[-1]  # last bottleneck layer for ResNet50
    cam = GradCAM(model=model, target_layers=[target_layer], use_cuda=(device.type=="cuda"))
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    saved = 0
    for idx, (imgs, labels) in enumerate(loader):
        if saved >= args.num_images:
            break
        input_tensor = imgs.to(device)
        img_for_vis = denormalize(imgs[0].cpu())  # HWC 0-1
        grayscale_cam = cam(input_tensor=input_tensor, targets=None)[0]  # HxW
        visualization = show_cam_on_image(img_for_vis, grayscale_cam, use_rgb=True)
        # Save overlay and raw heatmap
        out_path = out_dir / f"gradcam_{idx}_cls{labels.item()}.jpg"
        cv2.imwrite(str(out_path), cv2.cvtColor(visualization, cv2.COLOR_RGB2BGR))
        # Save raw heatmap as npy (for IoU later)
        np.save(str(out_dir / f"heatmap_{idx}.npy"), grayscale_cam)
        saved += 1
    print("Saved", saved, "Grad-CAM visualizations to", out_dir)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, required=True, help="Path to test images folder (ImageFolder layout)")
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--out_dir", type=str, default="/mnt/data/gradcam_out")
    parser.add_argument("--num_images", type=int, default=10)
    parser.add_argument("--img_size", type=int, default=224)
    parser.add_argument("--batch_size", type=int, default=1)
    args = parser.parse_args()
    main(args)
