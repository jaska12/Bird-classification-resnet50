"""
part3_detection_iou.py
Run YOLOv5 detection on test images and compute IoU between detection bounding boxes
and Grad-CAM high-activation regions.

Instructions (Colab):
1. clone yolov5 repo and install requirements (once):
   !git clone https://github.com/ultralytics/yolov5.git
   %cd yolov5
   !pip install -r requirements.txt
2. Run this script from the yolov5 repo root or adjust paths.
   python part3_detection_iou.py --images_dir /content/CUB_200_2011/test --gradcam_dir /content/gradcam_out --output_dir /content/detect_iou_out

Notes:
- This script uses the yolov5 detect API by invoking the detect/segment script and reading results.
- For simplicity we will call the yolov5 Python API if available; otherwise user can run detect.py manually and point --yolov5_res_dir to results.

This script:
- runs detection on each image
- loads corresponding grad-cam heatmap (.npy)
- thresholds top 20% to create binary mask
- computes IoU between mask's bounding box (or mask area) and detection boxes
- saves CSV of IoU scores and visualization images
"""

import os
import argparse
from pathlib import Path
import numpy as np
import cv2
import torch
import csv
from PIL import Image

def run_yolov5_detect(image_path, model_path=None, conf_thres=0.25, device='cuda'):
    # Try to use torch.hub to load yolov5 if available (internet disabled in some environments)
    # If not available, user should run yolov5/detect.py and set detections_dir.
    try:
        model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)  # may require internet
        model.conf = conf_thres
        results = model(image_path)
        # results.xyxy[0] -> [x1,y1,x2,y2,conf,class]
        dets = results.xyxy[0].cpu().numpy()
        return dets  # Nx6
    except Exception as e:
        print("torch.hub yolov5 load failed:", e)
        return None

def topk_mask_from_heatmap(heatmap, top_percent=20):
    # heatmap assumed HxW, values in 0..1
    flat = heatmap.flatten()
    threshold = np.percentile(flat, 100-top_percent)
    mask = (heatmap >= threshold).astype(np.uint8)
    return mask

def mask_to_bbox(mask):
    # returns x1,y1,x2,y2 or None
    ys, xs = np.where(mask>0)
    if len(xs)==0:
        return None
    x1, x2 = xs.min(), xs.max()
    y1, y2 = ys.min(), ys.max()
    return [int(x1), int(y1), int(x2), int(y2)]

def iou_box(boxA, boxB):
    # boxes: [x1,y1,x2,y2]
    if boxA is None or boxB is None:
        return 0.0
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])
    interW = max(0, xB - xA + 1)
    interH = max(0, yB - yA + 1)
    interArea = interW * interH
    boxAArea = (boxA[2]-boxA[0]+1)*(boxA[3]-boxA[1]+1)
    boxBArea = (boxB[2]-boxB[0]+1)*(boxB[3]-boxB[1]+1)
    iou = interArea / float(boxAArea + boxBArea - interArea + 1e-9)
    return iou

def main(args):
    images_dir = Path(args.images_dir)
    gradcam_dir = Path(args.gradcam_dir)
    out_dir = Path(args.output_dir); out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = out_dir / "iou_results.csv"
    rows = [["image","detection_idx","det_conf","det_class","det_box_x1","y1","x2","y2","mask_box_x1","y1_m","x2_m","y2_m","iou"]]
    for img_path in sorted(images_dir.glob("**/*.jpg")):
        name = img_path.stem
        heatmap_path = gradcam_dir / f"heatmap_{name.split('_')[-1]}.npy"
        # fallback: try any heatmap file that contains name
        if not heatmap_path.exists():
            # try pattern
            candidates = list(gradcam_dir.glob(f"heatmap*{name.split('_')[-1]}*.npy"))
            if candidates:
                heatmap_path = candidates[0]
        if not heatmap_path.exists():
            print("No heatmap for", img_path, "skipping.")
            continue
        heatmap = np.load(heatmap_path)
        # resize heatmap to image size
        img = cv2.imread(str(img_path))
        H,W = img.shape[:2]
        heatmap_resized = cv2.resize(heatmap, (W,H))
        mask = topk_mask_from_heatmap(heatmap_resized, top_percent=20)
        mask_box = mask_to_bbox(mask)
        dets = run_yolov5_detect(str(img_path), device=args.device)
        if dets is None:
            print("No detections for", img_path, "ensure yolov5 is installed or run detect.py separately.")
            continue
        for di, d in enumerate(dets):
            x1,y1,x2,y2,conf,cls = d.tolist()
            det_box = [int(x1),int(y1),int(x2),int(y2)]
            iou = iou_box(det_box, mask_box)
            rows.append([img_path.name, di, float(conf), int(cls), *det_box, *(mask_box if mask_box is not None else [None,None,None,None]), float(iou)])
        # visualization: draw det boxes and mask_box on image and save
        vis = img.copy()
        # draw detections
        for d in dets:
            x1,y1,x2,y2,conf,cls = d.tolist()
            cv2.rectangle(vis, (int(x1),int(y1)), (int(x2),int(y2)), (0,255,0), 2)
            cv2.putText(vis, f"{int(cls)} {conf:.2f}", (int(x1),int(y1)-5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)
        if mask_box is not None:
            cv2.rectangle(vis, (mask_box[0],mask_box[1]), (mask_box[2],mask_box[3]), (0,0,255), 2)
        cv2.imwrite(str(out_dir / f"{img_path.stem}_viz.jpg"), vis)
    # save CSV
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(rows)
    print("Saved IoU results to", csv_path)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--images_dir", type=str, required=True)
    parser.add_argument("--gradcam_dir", type=str, required=True)
    parser.add_argument("--output_dir", type=str, default="/mnt/data/detect_iou_out")
    parser.add_argument("--device", type=str, default="cuda")
    args = parser.parse_args()
    main(args)
