"""
part1_classification.py
ResNet50 fine-tuning on CUB-200-2011 (PyTorch)
Run on Google Colab (GPU recommended)

Main steps:
1. Install dependencies
   pip install -q torch torchvision timm kaggle matplotlib scikit-learn
2. Place kaggle.json into ~/.kaggle/ and set permissions, or use manual upload in Colab.
3. Download dataset:
   kaggle datasets download -d wenewone/cub2002011
   unzip the dataset and set DATA_DIR accordingly.
4. Run training:
   python part1_classification.py --data_dir /content/CUB_200_2011 --epochs 8 --batch_size 32 --save_dir /content/checkpoints

This script defines a dataset wrapper, dataloaders, ResNet50 fine-tune, training loop, evaluation,
and saves the best model. It also produces a confusion matrix PNG and prints accuracy.

Note: for speed in Colab, reduce epochs to 2-5 for testing.
"""

import argparse
import os
import time
from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import transforms, models, datasets
from torch.utils.data import DataLoader
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, accuracy_score

def get_dataloaders(data_dir, batch_size=32, img_size=224, num_workers=4):
    train_dir = os.path.join(data_dir, "train")
    test_dir = os.path.join(data_dir, "test")
    # If dataset has images in original CUB layout, use the ImageFolder-like layout. Otherwise user should reorganize.
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])
    train_tfm = transforms.Compose([
        transforms.Resize((img_size, img_size)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize
    ])
    test_tfm = transforms.Compose([
        transforms.Resize((img_size, img_size)),
        transforms.ToTensor(),
        normalize
    ])
    train_ds = datasets.ImageFolder(train_dir, transform=train_tfm)
    test_ds = datasets.ImageFolder(test_dir, transform=test_tfm)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    return train_loader, test_loader, train_ds.classes

def build_model(num_classes, device):
    model = models.resnet50(pretrained=True)
    # Replace final FC
    in_features = model.fc.in_features
    model.fc = nn.Linear(in_features, num_classes)
    model = model.to(device)
    return model

def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    for imgs, labels in loader:
        imgs = imgs.to(device); labels = labels.to(device)
        optimizer.zero_grad()
        outputs = model(imgs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * imgs.size(0)
        preds = outputs.argmax(dim=1)
        correct += (preds == labels).sum().item()
        total += imgs.size(0)
    return running_loss/total, correct/total

def evaluate(model, loader, device):
    model.eval()
    preds_all = []
    labels_all = []
    with torch.no_grad():
        for imgs, labels in loader:
            imgs = imgs.to(device)
            outputs = model(imgs)
            preds = outputs.argmax(dim=1).cpu().numpy()
            preds_all.extend(preds.tolist())
            labels_all.extend(labels.numpy().tolist())
    acc = accuracy_score(labels_all, preds_all)
    return acc, np.array(labels_all), np.array(preds_all)

def save_confusion(labels, preds, classes, out_path):
    cm = confusion_matrix(labels, preds, labels=range(len(classes)))
    disp = ConfusionMatrixDisplay(cm, display_labels=classes)
    fig, ax = plt.subplots(figsize=(12,12))
    disp.plot(ax=ax, xticks_rotation='vertical', cmap='Blues', colorbar=True)
    plt.title("Confusion Matrix")
    plt.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)

def main(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Device:", device)
    train_loader, test_loader, classes = get_dataloaders(args.data_dir, args.batch_size, args.img_size, args.num_workers)
    model = build_model(len(classes), device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=0.001, momentum=0.9, weight_decay=1e-4)
    best_acc = 0.0
    save_dir = Path(args.save_dir); save_dir.mkdir(parents=True, exist_ok=True)
    for epoch in range(1, args.epochs+1):
        start = time.time()
        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        test_acc, labels, preds = evaluate(model, test_loader, device)
        epoch_time = time.time() - start
        print(f"Epoch {epoch}/{args.epochs} - time {epoch_time:.1f}s - train_loss {train_loss:.4f} - train_acc {train_acc:.4f} - test_acc {test_acc:.4f}")
        if test_acc > best_acc:
            best_acc = test_acc
            torch.save(model.state_dict(), save_dir / "best_resnet50.pth")
            print("Saved best model.")
    # Final evaluation and confusion matrix
    print("Best test accuracy:", best_acc)
    save_confusion(labels, preds, classes, save_dir / "confusion_matrix.png")
    print("Saved confusion matrix to", save_dir / "confusion_matrix.png")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, required=True, help="Path to reorganized CUB train/test folders")
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--img_size", type=int, default=224)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--save_dir", type=str, default="/mnt/data/checkpoints")
    args = parser.parse_args()
    main(args)
