Assignment 1 — Deep Learning (CUB-200-2011)

Files created:
- part1_classification.py
- part2_gradcam.py
- part3_detection_iou.py

Quick Colab workflow:
1. Upload this folder to Colab or clone from your drive.
2. Ensure GPU runtime: Runtime -> Change runtime type -> GPU
3. Install dependencies:
   !pip install -q torch torchvision timm pytorch-grad-cam matplotlib scikit-learn opencv-python
4. Download dataset (Kaggle):
   - Upload kaggle.json to ~/.kaggle/ or use GUI upload.
   !kaggle datasets download -d wenewone/cub2002011
   !unzip cub2002011.zip -d /content/
   Then reorganize into train/ and test/ ImageFolder layout, or use the script to generate mapping.
5. Run part1 to train/fine-tune ResNet50:
   !python part1_classification.py --data_dir /content/CUB_200_2011 --epochs 6 --batch_size 32 --save_dir /content/checkpoints
6. Run Grad-CAM:
   !pip install -q pytorch-grad-cam
   !python part2_gradcam.py --data_dir /content/CUB_200_2011/test --model_path /content/checkpoints/best_resnet50.pth --out_dir /content/gradcam_out --num_images 10
7. Run YOLOv5 detection & IoU:
   # clone yolov5 and install
   !git clone https://github.com/ultralytics/yolov5.git
   %cd yolov5
   !pip install -r requirements.txt
   # copy part3_detection_iou.py into yolov5 folder or run with proper PYTHONPATH
   !python /content/assignment1_files/part3_detection_iou.py --images_dir /content/CUB_200_2011/test --gradcam_dir /content/gradcam_out --output_dir /content/detect_iou_out

Notes:
- Training CUB-200-2011 fully is heavy. For assignment/test use fewer epochs or a subset.
- If internet is unavailable in the environment, download dependencies in advance.
